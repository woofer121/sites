/* Carte artistique : coordonnées relatives à l’illustration, jamais présentées comme GPS. */
(() => {
  'use strict';
  const { days, events, photos, food, meals } = window.PRAGUE_DATA;
  const $ = (selector) => document.querySelector(selector);
  const svgNS = 'http://www.w3.org/2000/svg';
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const state = { day: 0, step: 0, view: 'map', playing: false, timer: null, zoom: 1, panX: 0, panY: 0, restaurants: false, selectedEvent: null, lastFocus: null };
  const photoCache = new Map();
  const photoRequests = new Map();
  const activeAnimations = [];
  // Points ajustés sur l’image locale 848 × 1264. null = hors carte ou adresse laissée libre.
  const points = [
    null, [61, 32], [72, 37], [77, 50], null, [45, 48],
    [27, 15], [10, 23], null, [29, 63], [72, 37], [81, 85],
    [62, 77], [61, 82], [90, 91], [72, 37], [65, 28], [77, 50],
    [72, 37], null, null, null
  ];
  const shortTitles = [
    'Vol Nice → Prague', 'Staroměstská', 'Kaprova 13', 'Vieille-Ville', 'Dîner libre', 'Pont Charles',
    'Château de Prague', 'Nový Svět', 'Déjeuner libre', 'Malá Strana & Kampa', 'Pause au logement', 'Place Venceslas',
    'Café Louvre', 'Národní & quais', 'Náměstí Míru', 'Pause au logement', 'Marina Ristorante', 'Dernière balade',
    'Départ du logement', 'Dernier café', 'Vers l’aéroport', 'Vol Prague → Nice'
  ];
  const restaurantPins = [
    { id: 'maitrea', name: 'Maitrea', point: [83, 43], type: 'Végétarien · suggestion, non réservée' },
    { id: 'lehka', name: 'Lehká Hlava', point: [63, 60], type: 'Végétarien · suggestion, non réservée' },
    { id: 'marina', name: 'Marina Ristorante', point: [65, 28], type: 'Bateau-restaurant · à réserver' },
    { id: 'louvre', name: 'Café Louvre', point: [62, 77], type: 'Petit-déjeuner · non réservé' }
  ];

  function node(tag, className, text) {
    const item = document.createElement(tag);
    if (className) item.className = className;
    if (text !== undefined) item.textContent = text;
    return item;
  }
  function svgNode(tag, attrs) {
    const item = document.createElementNS(svgNS, tag);
    Object.entries(attrs).forEach(([key, value]) => item.setAttribute(key, value));
    return item;
  }
  function dayEvents() { return events.map((event, index) => ({ event, index })).filter(({ event }) => event[0] === state.day); }
  function mapsUrl(query) { return 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(query); }
  function announce(text) { $('#live-status').textContent = text; }
  function clearAnimations() { activeAnimations.splice(0).forEach((animation) => animation.cancel()); }
  function writeHash() {
    const hash = `#jour=${state.day + 1}&etape=${state.step + 1}&vue=${state.view}`;
    try { history.replaceState(null, '', hash); } catch { /* Navigation toujours possible sans History API. */ }
  }
  function readHash() {
    const params = new URLSearchParams(location.hash.slice(1));
    const rawDay = Number(params.get('jour'));
    state.day = Number.isInteger(rawDay) && rawDay >= 1 && rawDay <= 4 ? rawDay - 1 : 0;
    const rawStep = Number(params.get('etape'));
    state.step = Number.isInteger(rawStep) && rawStep >= 1 && rawStep <= dayEvents().length ? rawStep - 1 : 0;
    state.view = params.get('vue') === 'carnet' ? 'carnet' : 'map';
  }
  function createDayButtons() {
    ['Jeu. 10', 'Ven. 11', 'Sam. 12', 'Dim. 13'].forEach((label, day) => {
      const button = node('button', 'day-button');
      button.type = 'button';
      button.dataset.day = day;
      button.setAttribute('aria-label', days[day][0] + ' 2026');
      button.setAttribute('aria-pressed', 'false');
      button.append(node('span', 'day-number', label), node('span', 'day-short', ['Arrivée', 'Ruelles', 'À deux', 'Retour'][day]));
      button.addEventListener('click', () => selectDay(day));
      $('#daybar').append(button);
    });
  }
  function setView(view, update = true) {
    stopPlayback();
    state.view = view;
    $('#map-view').hidden = view !== 'map';
    $('#carnet-view').hidden = view !== 'carnet';
    $('#view-map').setAttribute('aria-pressed', String(view === 'map'));
    $('#view-carnet').setAttribute('aria-pressed', String(view === 'carnet'));
    if (view === 'map') { renderRoute(false); applyTransform(); }
    if (update) writeHash();
  }
  function selectDay(day) {
    stopPlayback();
    state.day = day;
    state.step = 0;
    resetMap();
    renderDay();
    writeHash();
    if (state.view === 'carnet') $('#timeline-day-' + day).scrollIntoView({ behavior: reduceMotion.matches ? 'instant' : 'smooth', block: 'start' });
    announce(days[day][0] + '. ' + dayEvents().length + ' étapes.');
  }
  function renderDay() {
    document.querySelectorAll('.day-button').forEach((button, day) => button.setAttribute('aria-pressed', String(day === state.day)));
    $('#day-date').textContent = days[state.day][0] + ' · 2026';
    $('#day-title').textContent = days[state.day][1];
    $('#day-intro').textContent = days[state.day][2];
    $('#step-list').replaceChildren();
    $('#progress-track').replaceChildren();
    dayEvents().forEach(({ event }, step) => {
      const li = node('li');
      const button = node('button', 'step-button');
      button.type = 'button';
      button.dataset.step = step;
      button.append(node('span', 'step-num', String(step + 1)), node('span', '', event[2]), node('time', '', event[1]));
      button.addEventListener('click', () => { stopPlayback(); selectStep(step); });
      li.append(button);
      $('#step-list').append(li);
      $('#progress-track').append(node('span'));
    });
    renderPins();
    selectStep(state.step, false);
  }
  function selectStep(step, animate = true, update = true) {
    const list = dayEvents();
    if (step < 0 || step >= list.length) return;
    state.step = step;
    const { event, index } = list[step];
    $('#selected-time').textContent = event[1];
    $('#selected-title').textContent = event[2];
    $('#selected-subtitle').textContent = event[3];
    $('#selected-description').textContent = event[4];
    $('#selected-status').textContent = event[6];
    $('#selected-map').href = mapsUrl(event[5]);
    $('#selected-location').textContent = pointNote(index);
    renderMeals(index, $('#selected-meals'), false);
    $('#mobile-step-title').textContent = `${step + 1}. ${shortTitles[index]}`;
    $('#mobile-step-time').textContent = event[1];
    $('#step-count').textContent = `${step + 1} / ${list.length}`;
    $('#previous-step').disabled = step === 0;
    $('#next-step').disabled = step === list.length - 1;
    document.querySelectorAll('.step-button').forEach((button, i) => {
      if (i === step) button.setAttribute('aria-current', 'step');
      else button.removeAttribute('aria-current');
    });
    $('#progress-track').querySelectorAll('span').forEach((item, i) => item.classList.toggle('done', i <= step));
    document.querySelectorAll('.map-pin[data-step]').forEach((pin) => pin.setAttribute('aria-pressed', String(Number(pin.dataset.step) === step)));
    renderRoute(animate);
    if (animate && !reduceMotion.matches) {
      const animation = $('#selected-card').animate([{ opacity: .5, transform: 'translateY(5px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 250, easing: 'ease-out' });
      activeAnimations.push(animation);
    }
    if (update) writeHash();
    announce(`${days[state.day][0]}, étape ${step + 1} sur ${list.length} : ${event[1]}, ${event[2]}. ${points[index] ? '' : 'Étape sans repère sur la carte artistique.'}`);
  }
  function pointNote(index) {
    if (points[index]) return 'Repère illustratif approximatif ; utilise Maps pour te déplacer.';
    if ([0, 20, 21].includes(index)) return 'Hors du cadre de cette carte du centre : le trajet reste dans le programme.';
    return 'Adresse laissée libre dans le programme : aucun faux repère ajouté.';
  }
  function pixelPoint(point) { return [point[0] * 8.48, point[1] * 12.64]; }
  function pathBetween(a, b, bridgeCrossing = true) {
    const [x1, y1] = pixelPoint(a);
    const [x2, y2] = pixelPoint(b);
    // Lors d’une traversée, passer visuellement sur le pont illustré, pas à travers la Vltava.
    if (bridgeCrossing && ((a[0] < 38 && b[0] > 55) || (b[0] < 38 && a[0] > 55))) {
      const bridge = a[0] < b[0] ? [[28, 46], [59, 49]] : [[59, 49], [28, 46]];
      const p1 = pixelPoint(bridge[0]); const p2 = pixelPoint(bridge[1]);
      return `M ${x1} ${y1} Q ${x1} ${p1[1]} ${p1[0]} ${p1[1]} L ${p2[0]} ${p2[1]} Q ${x2} ${p2[1]} ${x2} ${y2}`;
    }
    return `M ${x1} ${y1} Q ${(x1 + x2) / 2 + Math.min(26, Math.abs(y2 - y1) / 8)} ${(y1 + y2) / 2} ${x2} ${y2}`;
  }
  function renderRoute(animate) {
    clearAnimations();
    const overlay = $('#route-overlay');
    overlay.replaceChildren();
    const mapped = dayEvents().map(({ index }, step) => ({ point: points[index], step })).filter((entry) => entry.point);
    for (let i = 1; i < mapped.length; i++) {
      const previous = mapped[i - 1]; const current = mapped[i];
      const d = pathBetween(previous.point, current.point);
      if (current.step <= state.step) {
        const outline = svgNode('path', { d, class: 'route-outline' });
        const path = svgNode('path', { d, class: 'route-segment' });
        overlay.append(outline, path);
        if (animate && current.step === state.step && !reduceMotion.matches && state.view === 'map') {
          const length = path.getTotalLength();
          [outline, path].forEach((line) => {
            line.style.strokeDasharray = String(length);
            activeAnimations.push(line.animate([{ strokeDashoffset: length }, { strokeDashoffset: 0 }], { duration: 1250, easing: 'cubic-bezier(.22,.68,.35,1)', fill: 'forwards' }));
          });
        }
      } else overlay.append(svgNode('path', { d, class: 'route-future' }));
    }
  }
  function makePin(point, number, title) {
    const pin = node('button', 'map-pin');
    pin.type = 'button';
    pin.style.left = point[0] + '%';
    pin.style.top = point[1] + '%';
    if (point[0] > 72) pin.dataset.edge = 'right';
    if (point[0] < 22) pin.dataset.edge = 'left';
    pin.append(node('span', 'pin-dot', String(number)), node('span', 'pin-label', title));
    return pin;
  }
  function renderPins() {
    const container = $('#map-pins');
    container.replaceChildren();
    const mapped = dayEvents().map(({ index }, step) => ({ index, step, point: points[index] })).filter(({ point }) => point);
    mapped.forEach(({ index, step, point }) => {
      let adjusted = [...point];
      const samePosition = mapped.filter((item) => item.point[0] === point[0] && item.point[1] === point[1]);
      if (samePosition.length > 1) {
        const order = samePosition.findIndex((item) => item.step === step);
        adjusted = [point[0] + (order - (samePosition.length - 1) / 2) * 11, point[1]];
      }
      const pin = makePin(adjusted, step + 1, shortTitles[index]);
      pin.dataset.step = step;
      pin.setAttribute('aria-label', `Étape ${step + 1} : ${events[index][2]}, ${events[index][1]}. Position approximative.`);
      pin.setAttribute('aria-pressed', String(step === state.step));
      pin.addEventListener('click', () => { stopPlayback(); selectStep(step); });
      container.append(pin);
    });
    if (state.restaurants) restaurantPins.forEach((restaurant, index) => {
      let point = [...restaurant.point];
      if (mapped.some((item) => Math.abs(item.point[0] - point[0]) < 8 && Math.abs(item.point[1] - point[1]) < 4)) point = [point[0] - 11, point[1] + 2];
      const pin = makePin(point, String.fromCharCode(65 + index), restaurant.name);
      pin.classList.add('restaurant-pin');
      pin.setAttribute('aria-label', `${restaurant.name} : ${restaurant.type}. Afficher les menus et options.`);
      pin.addEventListener('click', () => openRestaurant(restaurant));
      container.append(pin);
    });
  }
  function stopPlayback() {
    if (state.timer !== null) clearTimeout(state.timer);
    state.timer = null;
    state.playing = false;
    $('#play-button').textContent = 'Lire le parcours';
    $('#play-button').setAttribute('aria-pressed', 'false');
    $('#mobile-play').textContent = 'Lire';
    $('#mobile-play').setAttribute('aria-label', 'Lire le parcours');
  }
  function scheduleNext() {
    state.timer = setTimeout(() => {
      if (!state.playing) return;
      if (state.step >= dayEvents().length - 1) { stopPlayback(); announce('Parcours terminé. Toutes les étapes restent accessibles.'); return; }
      selectStep(state.step + 1);
      scheduleNext();
    }, 3600);
  }
  function togglePlayback() {
    if (state.playing) { stopPlayback(); announce('Lecture en pause.'); return; }
    if (state.step === dayEvents().length - 1) selectStep(0, false);
    state.playing = true;
    $('#play-button').textContent = 'Mettre en pause';
    $('#play-button').setAttribute('aria-pressed', 'true');
    $('#mobile-play').textContent = 'Pause';
    $('#mobile-play').setAttribute('aria-label', 'Mettre le parcours en pause');
    announce('Lecture du parcours. Une étape toutes les quatre secondes environ.');
    scheduleNext();
  }
  function renderTimeline() {
    days.forEach((day, dayIndex) => {
      const section = node('section', 'timeline-day');
      section.id = 'timeline-day-' + dayIndex;
      section.append(node('p', 'eyebrow', day[0] + ' · 2026'), node('h2', '', day[1]), node('p', 'day-intro', day[2]));
      const list = node('ol', 'timeline-list');
      events.forEach((event, index) => {
        if (event[0] !== dayIndex) return;
        const item = node('li');
        const button = node('button', 'timeline-card');
        button.type = 'button';
        button.dataset.event = index;
        button.setAttribute('aria-label', `${event[1]} : ${event[2]}. ${event[6]}. Tous les détails.`);
        const body = node('span');
        body.append(node('h3', '', event[2]), node('p', '', event[3]), node('span', 'badge', event[6]));
        button.append(node('time', 'time', event[1]), body, node('span', 'arrow', '↗'));
        button.addEventListener('click', () => openEvent(index));
        item.append(button); list.append(item);
      });
      section.append(list); $('#timeline-days').append(section);
    });
  }
  function renderMeals(index, target, detailed) {
    target.replaceChildren();
    const meal = meals[String(index)];
    target.hidden = !meal;
    if (!meal) return;
    target.append(node('h3', '', meal[0]));
    meal[1].forEach((key) => {
      const entry = food[key];
      const block = node('div', 'meal-option');
      block.append(node('strong', '', entry[0]), node('p', '', entry[1]));
      if (detailed) block.append(node('p', '', entry[2]));
      const links = node('div', 'meal-links');
      const menu = node('a', '', 'Carte officielle ↗');
      menu.href = entry[3]; menu.target = '_blank'; menu.rel = 'noopener noreferrer';
      const details = node('a', '', entry[4].startsWith('http') ? 'Site du restaurant ↗' : 'Photos & détails ↗');
      details.href = entry[4];
      if (entry[4].startsWith('http')) { details.target = '_blank'; details.rel = 'noopener noreferrer'; }
      links.append(menu, details);block.append(links);target.append(block);
    });
  }
  function openDialog() {
    stopPlayback();
    state.lastFocus = document.activeElement;
    if (!$('#event-dialog').open) $('#event-dialog').showModal();
  }
  function openEvent(index) {
    const event = events[index];
    state.selectedEvent = index;
    $('#dialog-title').textContent = event[2];
    $('#dialog-time').textContent = days[event[0]][0] + ' · ' + event[1];
    $('#dialog-subtitle').textContent = event[3];
    $('#dialog-status').textContent = event[6];
    $('#dialog-copy').textContent = event[4];
    renderMeals(index, $('#dialog-meals'), true);
    $('#dialog-map').href = mapsUrl(event[5]);
    $('#dialog-site').hidden = !event[7];
    $('#dialog-site').href = event[7] || '#';
    $('#dialog-site').textContent = event[6] === 'À réserver' ? 'Réserver sur le site ↗' : 'Site / infos pratiques ↗';
    $('#show-on-map').hidden = false;
    $('#show-on-map').textContent = points[index] ? 'Voir sur notre carte' : 'Retrouver dans le parcours';
    $('#photo-area').replaceChildren(); $('#photo-credit').replaceChildren();
    if (event[8]) showPhoto(event[8], index);
    else $('#photo-credit').textContent = 'Aucune photographie attribuée à cette étape libre ou à ce trajet.';
    openDialog();
  }
  function openRestaurant(restaurant) {
    state.selectedEvent = null;
    $('#dialog-meals').hidden = true;
    $('#dialog-meals').replaceChildren();
    $('#dialog-title').textContent = restaurant.name;
    $('#dialog-time').textContent = 'Suggestion de repas · position artistique approximative';
    $('#dialog-subtitle').textContent = restaurant.type;
    $('#dialog-status').textContent = 'Adresse repérée — pas de réservation créée';
    $('#dialog-copy').textContent = 'Cette adresse est une option, elle ne remplace pas le programme. Les plats et tarifs restent à confirmer. Consulte les menus et les précautions alimentaires sur la page des restaurants.';
    $('#dialog-map').href = mapsUrl(restaurant.name + ' Prague');
    $('#dialog-site').hidden = false; $('#dialog-site').href = './restaurants.html';
    $('#dialog-site').textContent = 'Menus & options sans viande ↗';
    $('#show-on-map').hidden = true;
    $('#photo-area').replaceChildren(); $('#photo-credit').replaceChildren();
    openDialog();
  }
  function closeDialog() { $('#event-dialog').close(); }
  function plainText(html) { return new DOMParser().parseFromString(html || '', 'text/html').body.textContent.trim(); }
  async function getPhoto(key) {
    if (photoCache.has(key)) return photoCache.get(key);
    if (photoRequests.has(key)) return photoRequests.get(key);
    const request = (async () => {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 6500);
      try {
        const params = new URLSearchParams({ action: 'query', format: 'json', origin: '*', prop: 'imageinfo', iiprop: 'url|extmetadata', iiurlwidth: '900', redirects: '1', titles: 'File:' + photos[key][0] });
        const response = await fetch('https://commons.wikimedia.org/w/api.php?' + params, { signal: controller.signal });
        if (!response.ok) throw new Error('Photo indisponible');
        const data = await response.json();
        const info = Object.values(data.query?.pages || {}).find((page) => page.imageinfo)?.imageinfo?.[0];
        if (!info) throw new Error('Photo manquante');
        const author = plainText(info.extmetadata?.Artist?.value);
        const license = plainText(info.extmetadata?.LicenseShortName?.value);
        const url = info.thumburl || info.url;
        if (!author || !license || !url || !/^https:\/\//.test(url)) throw new Error('Métadonnées incomplètes');
        const result = { url, author, license };
        photoCache.set(key, result); return result;
      } finally { clearTimeout(timeout); photoRequests.delete(key); }
    })();
    photoRequests.set(key, request);
    return request;
  }
  async function showPhoto(key, eventIndex) {
    const area = $('#photo-area');
    const source = node('a', '', 'Fiche originale, auteur et licence ↗');
    source.href = 'https://commons.wikimedia.org/wiki/File:' + encodeURIComponent(photos[key][0]);
    source.target = '_blank'; source.rel = 'noopener noreferrer';
    $('#photo-credit').replaceChildren(node('span', '', photos[key][1] + '. '), source);
    area.append(node('p', 'photo-message', 'Chargement de la photo du lieu…'));
    try {
      const info = await getPhoto(key);
      if (state.selectedEvent !== eventIndex) return;
      const image = node('img'); image.src = info.url; image.alt = photos[key][1];
      image.width = 900; image.height = 600; image.loading = 'lazy'; image.decoding = 'async';
      image.addEventListener('error', () => area.replaceChildren(node('p', 'photo-message', 'Photo indisponible. Le lien vers la fiche originale reste accessible.')));
      area.replaceChildren(image);
      $('#photo-credit').prepend(node('span', '', info.author + ' · ' + info.license + ' · photo recadrée. '));
    } catch {
      if (state.selectedEvent === eventIndex) area.replaceChildren(node('p', 'photo-message', 'Photo indisponible. Aucun autre lieu n’est utilisé à sa place.'));
    }
  }
  function applyTransform() {
    const viewport = $('#map-viewport');
    const stage = $('#map-stage');
    const maxX = Math.max(0, (stage.offsetWidth * state.zoom - viewport.clientWidth) / 2);
    const maxY = Math.max(0, (stage.offsetHeight * state.zoom - viewport.clientHeight) / 2);
    state.panX = Math.max(-maxX, Math.min(maxX, state.panX));
    state.panY = Math.max(-maxY, Math.min(maxY, state.panY));
    stage.style.transform = `translate(${state.panX}px, ${state.panY}px) scale(${state.zoom})`;
    $('#zoom-in').disabled = state.zoom >= 3;
    $('#zoom-out').disabled = state.zoom <= 1;
  }
  function setZoom(zoom) { state.zoom = Math.max(1, Math.min(3, zoom)); applyTransform(); }
  function resetMap() { state.zoom = 1; state.panX = 0; state.panY = 0; applyTransform(); }
  function setupMapGestures() {
    const viewport = $('#map-viewport');
    const pointers = new Map(); let drag = null; let pinch = null;
    viewport.addEventListener('pointerdown', (event) => {
      if (event.target.closest('button,a')) return;
      pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      viewport.setPointerCapture(event.pointerId);
      if (pointers.size === 1) drag = { x: event.clientX, y: event.clientY, panX: state.panX, panY: state.panY };
      if (pointers.size === 2) {
        const values = [...pointers.values()];
        pinch = { distance: Math.hypot(values[0].x - values[1].x, values[0].y - values[1].y), zoom: state.zoom };
      }
    });
    viewport.addEventListener('pointermove', (event) => {
      if (!pointers.has(event.pointerId)) return;
      pointers.set(event.pointerId, { x: event.clientX, y: event.clientY });
      if (pointers.size === 2 && pinch) {
        const values = [...pointers.values()];
        setZoom(pinch.zoom * Math.hypot(values[0].x - values[1].x, values[0].y - values[1].y) / Math.max(1, pinch.distance));
      } else if (pointers.size === 1 && drag && state.zoom > 1) {
        state.panX = drag.panX + event.clientX - drag.x; state.panY = drag.panY + event.clientY - drag.y; applyTransform();
      }
    });
    function end(event) {
      pointers.delete(event.pointerId); pinch = null;
      if (pointers.size === 1) { const value = [...pointers.values()][0]; drag = { ...value, panX: state.panX, panY: state.panY }; }
      else drag = null;
    }
    viewport.addEventListener('pointerup', end); viewport.addEventListener('pointercancel', end);
    viewport.addEventListener('wheel', (event) => {
      if (!event.ctrlKey && !event.metaKey) return;
      event.preventDefault(); setZoom(state.zoom + (event.deltaY < 0 ? .2 : -.2));
    }, { passive: false });
  }
  function setupTheme() {
    const system = window.matchMedia('(prefers-color-scheme: dark)');
    let manual = false;
    function apply(theme) {
      document.documentElement.dataset.theme = theme;
      $('#theme-toggle').setAttribute('aria-label', theme === 'dark' ? 'Passer au thème clair' : 'Passer au thème sombre');
      $('#theme-toggle').setAttribute('aria-pressed', String(theme === 'dark'));
    }
    apply(system.matches ? 'dark' : 'light');
    $('#theme-toggle').addEventListener('click', () => { manual = true; apply(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'); });
    system.addEventListener('change', (event) => { if (!manual) apply(event.matches ? 'dark' : 'light'); });
  }

  createDayButtons(); renderTimeline(); readHash(); setupTheme(); renderDay(); setView(state.view, false); setupMapGestures();
  $('#view-map').addEventListener('click', () => setView('map'));
  $('#view-carnet').addEventListener('click', () => setView('carnet'));
  $('#previous-step').addEventListener('click', () => { stopPlayback(); selectStep(state.step - 1); });
  $('#next-step').addEventListener('click', () => { stopPlayback(); selectStep(state.step + 1); });
  $('#play-button').addEventListener('click', togglePlayback);
  $('#mobile-play').addEventListener('click', togglePlayback);
  $('#mobile-details').addEventListener('click', () => openEvent(dayEvents()[state.step].index));
  $('#details-button').addEventListener('click', () => openEvent(dayEvents()[state.step].index));
  $('#close-dialog').addEventListener('click', closeDialog);
  $('#event-dialog').addEventListener('close', () => { state.lastFocus?.focus({ preventScroll: true }); });
  $('#event-dialog').addEventListener('click', (event) => {
    if (event.target !== $('#event-dialog')) return;
    const rect = $('#event-dialog').getBoundingClientRect();
    if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) closeDialog();
  });
  $('#show-on-map').addEventListener('click', () => {
    const index = state.selectedEvent;
    if (index === null) return;
    closeDialog(); state.day = events[index][0];
    state.step = dayEvents().findIndex((item) => item.index === index);
    resetMap(); renderDay(); setView('map');
    $('#map-view').scrollIntoView({ behavior: reduceMotion.matches ? 'instant' : 'smooth' });
    $('#details-button').focus({ preventScroll: true });
  });
  $('#restaurants-toggle').addEventListener('change', (event) => { state.restaurants = event.target.checked; renderPins(); });
  $('#zoom-in').addEventListener('click', () => setZoom(state.zoom + .35));
  $('#zoom-out').addEventListener('click', () => setZoom(state.zoom - .35));
  $('#zoom-reset').addEventListener('click', resetMap);
  $('#print-button').addEventListener('click', () => { setView('carnet'); window.print(); });
  $('#map-image').addEventListener('error', () => { $('#map-fallback').hidden = false; });
  $('#map-image').addEventListener('load', () => { $('#map-fallback').hidden = true; });
  if ($('#map-image').complete && !$('#map-image').naturalWidth) $('#map-fallback').hidden = false;
  $('#retry-map').addEventListener('click', () => { $('#map-image').src = './assets/prague-map.webp?retry=' + Date.now(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) stopPlayback(); });
  window.addEventListener('resize', applyTransform);
  window.addEventListener('hashchange', () => { stopPlayback(); readHash(); resetMap(); renderDay(); setView(state.view, false); });
  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') stopPlayback();
    if ($('#event-dialog').open || event.target.closest('input,textarea,select') || state.view !== 'map') return;
    if (event.key === 'ArrowRight') { event.preventDefault(); stopPlayback(); selectStep(state.step + 1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); stopPlayback(); selectStep(state.step - 1); }
  });
})();
