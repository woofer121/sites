/* Programme et suggestions repas repris du carnet distant 758a158. */
window.PRAGUE_DATA = {
  "photos": {
    "old": [
      "Prague Old Town Square, Czech Republic - Oct 2010.jpg",
      "Place de la Vieille-Ville — vue du lieu, hors marché de Noël"
    ],
    "bridge": [
      "Night view of the Castle and Charles Bridge, Prague - 8034.jpg",
      "Pont Charles et château de Prague, de nuit"
    ],
    "castle": [
      "Prague castle 3.jpg",
      "Château de Prague vu depuis la Vltava"
    ],
    "novy": [
      "Praha, Novy Svet (Prague) - 51989595865.jpg",
      "Ruelle de Nový Svět"
    ],
    "kampa": [
      "Kampa Island Prague (51621511422).jpg",
      "Île de Kampa"
    ],
    "wenceslas": [
      "Wenceslas Square.jpg",
      "Place Venceslas, de nuit"
    ],
    "louvre": [
      "Praha Café Louvre.JPG",
      "Café Louvre, Prague"
    ],
    "miru": [
      "Praha, Náměstí míru, předvánoční trhy II.jpg",
      "Marché de Noël de Náměstí Míru — photo d’une édition passée"
    ],
    "marina": [
      "Marina Ristorante (Prague), 2019 (01).jpg",
      "Entrée du Marina Ristorante — photo de 2019"
    ],
    "home": [
      "Josefov, Kaprova 13.jpg",
      "Façade du 13 Kaprova — adresse du logement, pas une photo des chambres"
    ],
    "maitrea": [
      "Pametni deska Karla Skrety (dum U Cerneho jelena, Tynska ulicka 6).jpg",
      "Plaque sur le bâtiment du 6 Týnská ulička — repère d’adresse, pas la salle du Maitrea"
    ],
    "lehka": [
      "Měšťanský dům, Boršov 2, Staré Město (Praha), Hlavní město Praha 03.jpg",
      "Bâtiment du Lehká Hlava au 2 Boršov — extérieur"
    ]
  },
  "days": [
    [
      "Jeudi 10 décembre",
      "Notre première soirée de Noël",
      "On arrive, on pose les valises… et Prague s’illumine."
    ],
    [
      "Vendredi 11 décembre",
      "Un château et des ruelles",
      "Les incontournables, à notre rythme."
    ],
    [
      "Samedi 12 décembre",
      "Une journée rien qu’à nous",
      "Café, flânerie et dîner sur la Vltava."
    ],
    [
      "Dimanche 13 décembre",
      "Encore un peu de Prague",
      "Un dernier café avant de rentrer."
    ]
  ],
  "events": [
    [
      0,
      "13:00 → 14:45",
      "Envol pour Prague",
      "Nice → Prague · vol EJU1781",
      "Horaires figurant sur le billet fourni. Arrivée à Prague au terminal 2. Vérifier les informations de vol dans l’application de la compagnie avant le départ.",
      "Vaclav Havel Airport Prague",
      "Réservé",
      "",
      "",
      "✈️"
    ],
    [
      0,
      "Vers 15:30",
      "Direction le centre",
      "Trolleybus 59 + métro A",
      "Prendre le 59 vers Nádraží Veleslavín, puis le métro A vers Staroměstská. Départ indicatif : prévoir une marge pour le débarquement et les bagages.",
      "Staroměstská Prague",
      "Proposé",
      "https://www.prg.aero/en/public-transport-buses",
      "",
      "🚎"
    ],
    [
      0,
      "16:00 – 16:30",
      "Notre petit point de départ",
      "Kafka Prague rooms · Kaprova 13",
      "Réservation du 10 au 13 décembre. Arrivée autorisée entre 16 h et 20 h. Adresse indiquée : 13 Kaprova, 4. patro. Prévenir l’hôte de l’heure estimée ; ascenseur non vérifié. La photo montre uniquement la façade à cette adresse.",
      "Kafka Prague rooms Kaprova 13 Prague",
      "Réservé",
      "",
      "home",
      ""
    ],
    [
      0,
      "17:00",
      "La magie de la Vieille-Ville",
      "Marché de Noël & horloge astronomique",
      "Premier tour sans se presser : place de la Vieille-Ville, horloge, ruelles et pause gourmande. Le marché est annoncé du 28 novembre 2026 au 6 janvier 2027. La photo montre la place hors période du marché.",
      "Old Town Square Prague",
      "Proposé",
      "https://prague.eu/en/akce/old-town-square-christmas-market/",
      "old",
      ""
    ],
    [
      0,
      "19:00",
      "Premier dîner à deux",
      "Vieille-Ville · Maitrea ou Marina",
      "Deux options dans le secteur de la Vieille-Ville : Maitrea près de la place, ou Marina côté fleuve en direction du pont Charles. Choisir selon la fatigue ; si vous gardez Marina pour samedi, privilégier Maitrea ce soir. Aucune réservation effectuée.",
      "Old Town Prague",
      "Proposé",
      "",
      "",
      "🍽️"
    ],
    [
      0,
      "20:30",
      "Prague au fil de l’eau",
      "Petite balade vers le pont Charles",
      "Option selon notre énergie et la météo : quelques photos, une vue sur la Vltava, puis retour au logement.",
      "Charles Bridge Prague",
      "Proposé",
      "",
      "bridge",
      ""
    ],
    [
      1,
      "09:00 – 12:00",
      "Le château de Prague",
      "Cathédrale, palais et ruelle d’Or",
      "Choisir les intérieurs selon nos envies et le billet retenu. Les bâtiments historiques ont un horaire hivernal de 9 h à 16 h ; vérifier les fermetures ponctuelles et le tarif avant achat. Aucun billet acheté.",
      "Prague Castle",
      "Proposé",
      "https://www.hrad.cz/en/prague-castle-for-visitors/opening-hours",
      "castle",
      ""
    ],
    [
      1,
      "12:00",
      "Se perdre dans Nový Svět",
      "Une parenthèse dans les petites rues",
      "Balade proposée après le château. Pause au café U Raka en option : horaires de décembre à vérifier. Adresse repérée dans les publications sociales, sans garantie d’ouverture.",
      "Nový Svět Prague",
      "Proposé",
      "",
      "novy",
      ""
    ],
    [
      1,
      "13:00",
      "Déjeuner au chaud",
      "Descente vers Malá Strana · Nerudova",
      "Option principale : Vegan’s Prague au 36 Nerudova en descendant du quartier du château. Alternative Dosa Dosa à Újezd 43 seulement si vous avancez vers Kampa/Újezd avant de déjeuner : ce n’est pas juste à côté du château. Menus et horaires à revérifier.",
      "Nerudova 36 Prague",
      "Proposé",
      "",
      "",
      "🍽️"
    ],
    [
      1,
      "14:00 – 16:30",
      "Malá Strana & Kampa",
      "Ruelles, île et promenade à deux",
      "Descendre vers Malá Strana, continuer vers Kampa puis revenir par le pont Charles. Raccourcir la boucle si le froid ou la pluie s’invitent. La photo montre Kampa, une étape de cette balade.",
      "Kampa Island Prague",
      "Proposé",
      "",
      "kampa",
      ""
    ],
    [
      1,
      "17:00",
      "Une pause rien qu’à nous",
      "Retour au logement",
      "Temps libre pour se réchauffer, se reposer et décider de la soirée. Aucune réservation à respecter.",
      "Kafka Prague rooms Kaprova Prague",
      "Proposé",
      "",
      "home",
      ""
    ],
    [
      1,
      "19:00",
      "Dîner puis Noël place Venceslas",
      "Lehká Hlava ou Café Louvre, puis le marché",
      "Lehká Hlava à Boršov : option de dîner dans le centre avant de continuer vers Venceslas. Alternative Café Louvre à Národní, plus cohérent si vous rejoignez ensuite la place par le sud ; vérifier sa carte du dîner, différente du petit-déjeuner. Aucun des deux n’est sur la place Venceslas. Marché et décorations à revérifier.",
      "Wenceslas Square Prague",
      "Proposé",
      "https://www.pragueexperience.com/events/christmas-markets.asp",
      "wenceslas",
      ""
    ],
    [
      2,
      "09:30",
      "Un matin au Café Louvre",
      "Petit-déjeuner à Národní",
      "Adresse proposée pour démarrer doucement. Carte, horaires et éventuelle attente à vérifier avant le séjour ; aucune table réservée. Plusieurs options sans viande : omelette ciboulette, pancakes au saumon ou formule Fit.",
      "Café Louvre Prague",
      "Proposé",
      "https://www.cafelouvre.cz/en/food-drink",
      "louvre",
      ""
    ],
    [
      2,
      "11:00 – 14:00",
      "Au rythme de nos envies",
      "Národní, quais et déjeuner libre",
      "Boucle souple vers la Vltava puis la vieille ville. Pour déjeuner avant Náměstí Míru : Lehká Hlava si vous êtes vers Boršov/quais ; Café Louvre si vous restez vers Národní. Ces deux options sont avant le trajet vers Náměstí Míru, pas à côté de ce marché.",
      "Národní Prague",
      "Proposé",
      "",
      "",
      "🚶"
    ],
    [
      2,
      "14:00 – 16:30",
      "Un autre marché de Noël",
      "Náměstí Míru",
      "Proposition pour sortir un peu du circuit des deux grandes places. Dates annoncées : 20 novembre au 24 décembre. Vérifier les horaires peu avant le départ. La photo représente bien le marché de Náměstí Míru, lors d’une édition passée.",
      "Náměstí Míru Prague",
      "Proposé",
      "https://www.pragueexperience.com/events/christmas-markets.asp",
      "miru",
      ""
    ],
    [
      2,
      "17:00",
      "On se prépare pour ce soir",
      "Pause au logement",
      "Le temps de se poser avant notre dernier grand dîner.",
      "Kafka Prague rooms Kaprova Prague",
      "Proposé",
      "",
      "home",
      ""
    ],
    [
      2,
      "19:00",
      "Dîner sur la Vltava",
      "Marina · alternative Maitrea après le logement",
      "Marina au bord de la Vltava après le retour au logement de Kaprova. Alternative Maitrea dans la Vieille-Ville si Marina ne convient pas. Demander au Marina une table intérieure près d’une fenêtre et signaler : pas de viande, poisson accepté. La photo montre l’entrée du restaurant en 2019, pas l’intérieur ni une table réservée.",
      "Marina Ristorante Prague",
      "À réserver",
      "https://www.marinaristorante.cz/en/reservation",
      "marina",
      ""
    ],
    [
      2,
      "20:45",
      "Une dernière soirée illuminée",
      "La ville, juste nous deux",
      "Balade facultative au bord de l’eau ou retour vers le marché de la Vieille-Ville. Pas d’activité payante bloquée pour garder notre liberté. La photo montre le pont Charles et le château de nuit, pour l’option au bord de l’eau.",
      "Old Town Square Prague",
      "Proposé",
      "",
      "bridge",
      ""
    ],
    [
      3,
      "Avant 10:00",
      "On rend les clés",
      "Départ de Kafka Prague rooms",
      "Départ indiqué entre 8 h et 10 h. Demander à l’avance si les bagages peuvent être gardés : ce service n’est pas confirmé.",
      "Kafka Prague rooms Kaprova Prague",
      "Horaire du séjour",
      "",
      "home",
      ""
    ],
    [
      3,
      "10:00 – 12:30",
      "Un dernier café à Prague",
      "Café libre près du logement ou détour par Louvre",
      "Option la plus souple : choisir un café dans la Vieille-Ville en fonction des bagages. Café Louvre à Národní est une alternative avec détour vers le sud, pas une adresse juste à côté de Kaprova. Garder la marge pour le départ vers l’aéroport.",
      "Old Town Prague",
      "Proposé",
      "",
      "",
      "☕"
    ],
    [
      3,
      "Vers 13:00",
      "Direction l’aéroport",
      "Objectif : terminal 2 vers 14 h 30",
      "Métro A jusqu’à Nádraží Veleslavín, puis trolleybus 59. Horaire proposé avec marge pour le vol de 16 h 45 ; vérifier les consignes de la compagnie.",
      "Prague Airport Terminal 2",
      "Proposé",
      "https://www.prg.aero/en/public-transport-buses",
      "",
      "🚎"
    ],
    [
      3,
      "16:45 → 18:35",
      "Des souvenirs plein les yeux",
      "Prague → Nice · vol EJU1782",
      "Horaire du billet fourni. Départ du terminal 2 à Prague. Le retour est bien le dimanche 13 décembre, et non le 14.",
      "Nice Côte d’Azur Airport",
      "Réservé",
      "",
      "",
      "✈️"
    ]
  ],
  "food": {
    "maitrea": [
      "Maitrea",
      "Týnská ulička 1064/6 · Vieille-Ville",
      "Végétarien. Extraits de la carte du 04/11/2026 : svíčková végétarienne 335 Kč ; lasagnes 330 Kč. Prix à revérifier.",
      "https://restaurace-maitrea.cz/en/menu-vegetarian-and-vegan-restaurant/",
      "restaurants.html#maitrea",
      "maitrea"
    ],
    "marina": [
      "Marina Ristorante",
      "Alšovo nábřeží 10 · bord de Vltava",
      "Italien. Linguine fruits de mer 655 Kč ; pappardelle tomate et burrata 415 Kč, selon la carte du 04/11/2026. Vérifier l’absence de viande dans sauces et garnitures.",
      "https://www.marinaristorante.cz/en/menu",
      "restaurants.html#marina",
      "marina"
    ],
    "lehka": [
      "Lehká Hlava",
      "Boršov 280/2 · Vieille-Ville",
      "Végétarien. Svíčková végétarienne 325 Kč ; bao burger tofu 345 Kč, carte du 04/11/2026, à revérifier.",
      "https://lehkahlava.cz/en/",
      "restaurants.html#lehka",
      "lehka"
    ],
    "louvre": [
      "Café Louvre",
      "Národní 22 · Nové Město",
      "Carte matin : omelette ciboulette 129 Kč ; pancakes saumon 229 Kč. Pour midi/soir, consulter la carte correspondante : ne pas appliquer les prix du matin au dîner.",
      "https://www.cafelouvre.cz/en/food-drink",
      "restaurants.html#louvre",
      "louvre"
    ],
    "vegan": [
      "Vegan’s Prague",
      "Nerudova 36 · Malá Strana",
      "Restaurant végétalien pour déjeuner en descendant du château. Carte officielle en ligne ; aucun prix non vérifié affiché. Pas de photo précise validée ici : illustration explicitement signalée.",
      "https://vegansprague.cz/menu/online-menu",
      "https://vegansprague.cz/",
      ""
    ],
    "dosa": [
      "Dosa Dosa",
      "Újezd 43 · Malá Strana",
      "Alternative après une descente plus loin vers Kampa/Újezd. Dosa pommes de terre et sambar : grande 285 Kč ; tofu tikka masala 280 Kč sur la carte consultée le 04/11/2026. Pas de photo précise validée : illustration.",
      "https://www.dosadosa.cz/menu-1?menu=english-menu",
      "https://www.dosadosa.cz/",
      ""
    ]
  },
  "meals": {
    "4": [
      "Vieille-Ville, après le marché",
      [
        "maitrea",
        "marina"
      ]
    ],
    "8": [
      "Déjeuner côté château → Malá Strana",
      [
        "vegan",
        "dosa"
      ]
    ],
    "11": [
      "Dîner dans le centre avant Venceslas",
      [
        "lehka",
        "louvre"
      ]
    ],
    "12": [
      "Petit-déjeuner à Národní",
      [
        "louvre"
      ]
    ],
    "13": [
      "Déjeuner avant de rejoindre Náměstí Míru",
      [
        "lehka",
        "louvre"
      ]
    ],
    "16": [
      "Après le retour à Kaprova : fleuve ou Vieille-Ville",
      [
        "marina",
        "maitrea"
      ]
    ],
    "19": [
      "Matin du départ : garder une marge pour les bagages",
      [
        "louvre"
      ]
    ]
  }
};
