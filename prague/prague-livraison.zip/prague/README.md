# Prague, à deux — carte & carnet

## Ce qui a été repris

Base distante : `758a15804d5e7b710fdb9a4f7397e1754d599b78` (4 novembre 2026).
Les modifications concurrentes des suggestions de repas ont été intégrées : les
22 étapes, leurs horaires, descriptions, statuts, liens, les 4 jours et les
suggestions restaurants sont conservés dans `assets/itinerary.js`.
`tests/programme-original.json` est le témoin de ces données extraites du carnet.
`restaurants.html`, l’illustration originale et le reste du dépôt sont inchangés.

## Carte

- Illustration originale existante `assets/prague-map.webp`, pas la capture du Reel.
- Quatre jours, repères numérotés, tracé rouge progressif et lecture/pause.
- Sélection synchronisée entre carte, liste et fiches du carnet.
- Zoom, recentrage, déplacement et pincement tactile ; commandes clavier.
- Suggestions repas, menus et liens Maps, thèmes clair et sombre.
- Carnet intégral, fiches avec provenance des photos, impression et programme texte.
- URL partageable : `#jour=2&etape=4&vue=map`.

Les positions sont artistiques et approximatives : aucun calcul GPS ni itinéraire
piéton réel n’est prétendu. Les étapes hors cadre restent dans le programme et
les repas non fixés n’ont pas de faux repère. Rien n’est réservé par cette page.

Le fichier préexistant `frame_0.jpg` contient du texte, pas une image valide ; il
est laissé intact mais n’est plus utilisé. Les polices et photos nécessitent
Internet. Le fond illustré et les données du programme sont locaux ; les photos
ont un retour explicite si le réseau est indisponible. Aucune photo d’un autre
lieu n’est utilisée comme remplacement.

## Tester localement

Depuis la racine du dépôt :

```sh
python -m http.server 8000
# Ouvrir http://localhost:8000/prague/
```

Suite navigateur (Python 3.12 et Playwright, Chromium) :

```sh
python -m pip install playwright
python -m playwright install chromium
python prague/tests/test_prague.py --output /tmp/prague-results.json
```

Option `--browser /chemin/vers/chromium` pour un navigateur déjà installé.
Option `--axe /chemin/vers/axe.min.js` pour inclure les contrôles WCAG A/AA.
L’outil axe-core peut être installé dans un dossier temporaire :

```sh
npm install --prefix /tmp/prague-qa axe-core@4
python prague/tests/test_prague.py \
  --axe /tmp/prague-qa/node_modules/axe-core/axe.min.js \
  --output /tmp/prague-results.json
```

Lint :

```sh
cd prague
npx --yes --package eslint@9 eslint --config eslint.config.mjs assets/app.js assets/itinerary.js
```

## Validation effectuée

67 contrôles réussis, résultat détaillé dans `tests/results.json` : conservation
du programme et des suggestions concurrentes, navigation des 22 fiches, repères,
lecture/pause/fin de lecture, zoom et déplacement, pincement tactile, liens
directs, clavier, retour du focus, largeurs 375/390/768/1280/1440/1920 px, zoom
200 %, thèmes, mouvement réduit, contrôles axe et erreurs réseau. Les filtres de
la page restaurants existante fonctionnent. Les contrôles axe automatisés ne
remplacent pas un audit manuel complet. Testé dans Chromium, pas dans Safari
ni Firefox. Le succès de l’API photo a été testé par réponse contrôlée ; l’accès
réel aux photos dépend du réseau. Le lint des scripts nouveaux et du script
restaurants existant passe. Aucune erreur JavaScript non gérée dans la suite.

## Publication

Cette validation concerne la version locale. Elle ne vaut pas preuve de
publication. Un accès GitHub en écriture est nécessaire pour pousser le commit,
puis il faut vérifier la réussite du déploiement GitHub Pages et ouvrir
`https://woofer121.github.io/sites/prague/` pour contrôler la révision réellement
servie. Ne jamais annoncer « publié » sur la seule base d’un fichier ou commit local.
