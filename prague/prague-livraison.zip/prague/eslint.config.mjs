export default [{
  languageOptions: { ecmaVersion: 2022, sourceType: 'script', globals: Object.fromEntries(['window','document','history','location','setTimeout','clearTimeout','URLSearchParams','AbortController','fetch','DOMParser','console'].map(key => [key, 'readonly'])) },
  rules: { 'no-undef': 'error', 'no-unused-vars': ['error', { caughtErrors: 'none' }], 'no-unreachable': 'error', 'no-constant-condition': 'error', 'valid-typeof': 'error' }
}];
