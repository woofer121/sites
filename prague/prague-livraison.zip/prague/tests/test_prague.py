"""Tests navigateur : python -m pip install playwright ; playwright install chromium.
Puis python prague/tests/test_prague.py --base-url http://localhost:8000/prague/
Option : --browser /chemin/vers/chromium --axe /chemin/vers/axe.min.js
"""
import argparse
import hashlib
import json
from pathlib import Path
import threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from playwright.sync_api import sync_playwright, expect

parser = argparse.ArgumentParser()
parser.add_argument('--base-url')
parser.add_argument('--browser')
parser.add_argument('--axe')
parser.add_argument('--output', default='prague-test-results.json')
args = parser.parse_args()
root = Path(__file__).resolve().parents[1]
expected = json.loads((root / 'tests/programme-original.json').read_text())
server = None
if not args.base_url:
    handler = partial(SimpleHTTPRequestHandler, directory=str(root.parent))
    server = ThreadingHTTPServer(('127.0.0.1', 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    args.base_url = f'http://127.0.0.1:{server.server_port}/prague/'
base = args.base_url
checks = []
errors = []

def check(name, condition=True):
    if not condition:
        raise AssertionError(name)
    checks.append({'test': name, 'result': 'PASS'})

def wait_ui(page):
    page.wait_for_timeout(450)

try:
    with sync_playwright() as playwright:
        options = {'headless': True, 'args': ['--no-sandbox']}
        if args.browser:
            options['executable_path'] = args.browser
        browser = playwright.chromium.launch(**options)
        page = browser.new_page(viewport={'width': 1440, 'height': 1100})
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto(base, wait_until='domcontentloaded')
        page.wait_for_function('window.PRAGUE_DATA && document.querySelectorAll(".timeline-card").length === 22')
        page.wait_for_function('document.querySelector("#map-image").naturalWidth > 0')
        check('Programme original : données, 22 étapes, 4 jours et sources photo inchangés', page.evaluate('window.PRAGUE_DATA') == expected)
        check('Illustration locale valide', page.locator('#map-image').evaluate('(img)=>img.naturalWidth===848&&img.naturalHeight===1264'))
        check('Aucun marqueur de conflit Git affiché', not page.locator('body').inner_text().find('>>>>>>>') >= 0)
        for day, count in enumerate([6, 6, 6, 4]):
            page.locator('.day-button').nth(day).click()
            expect(page.locator('.step-button')).to_have_count(count)
            expect(page.locator('.day-button').nth(day)).to_have_attribute('aria-pressed', 'true')
            for step in range(count):
                page.locator('.step-button').nth(step).click()
                index = [i for i, event in enumerate(expected['events']) if event[0] == day][step]
                event = expected['events'][index]
                expect(page.locator('#selected-title')).to_have_text(event[2])
                expect(page.locator('#selected-description')).to_have_text(event[4])
                expect(page.locator('#selected-time')).to_have_text(event[1])
                expect(page.locator('#selected-status')).to_have_text(event[6])
                check(f'Jour {day + 1}, étape {step + 1} : titre, horaire, description et statut')
            check(f'Jour {day + 1} : nombre exact d’étapes et sélection du jour')
        page.locator('.day-button').nth(1).click()
        expect(page.locator('.map-pin[data-step]')).to_have_count(5)
        check('Déjeuner laissé libre : aucun faux repère sur la carte')
        page.locator('.map-pin[data-step="3"]').click()
        expect(page.locator('#selected-title')).to_have_text('Malá Strana & Kampa')
        check('Repère cliquable synchronisé avec la fiche et la liste')
        page.wait_for_timeout(1400)
        check('Parcours SVG tracé et animé', page.locator('.route-segment').count() == 2)
        page.locator('#restaurants-toggle').check()
        expect(page.locator('.restaurant-pin')).to_have_count(4)
        page.locator('.restaurant-pin').first.click()
        expect(page.locator('#event-dialog')).to_be_visible()
        expect(page.locator('#dialog-title')).to_have_text('Maitrea')
        check('Quatre suggestions de repas, détails et lien vers la page conservée')
        page.keyboard.press('Escape')
        page.locator('#restaurants-toggle').uncheck()
        page.locator('#zoom-in').click()
        before = page.locator('#map-stage').evaluate('(el)=>el.style.transform')
        viewport = page.locator('#map-viewport').bounding_box()
        x = viewport['x'] + viewport['width'] / 2
        y = viewport['y'] + viewport['height'] * .8
        page.mouse.move(x, y); page.mouse.down(); page.mouse.move(x + 70, y + 30, steps=5); page.mouse.up()
        after = page.locator('#map-stage').evaluate('(el)=>el.style.transform')
        check('Zoom et déplacement de la carte', '1.35' in before and before != after)
        page.locator('#zoom-reset').click()
        expect(page.locator('#zoom-out')).to_be_disabled()
        check('Recentrage et limites de zoom')
        page.locator('.day-button').nth(0).click()
        page.locator('#play-button').click()
        expect(page.locator('#play-button')).to_have_attribute('aria-pressed', 'true')
        page.wait_for_timeout(3800)
        expect(page.locator('#step-count')).to_have_text('2 / 6')
        page.locator('#play-button').click()
        page.wait_for_timeout(3800)
        expect(page.locator('#step-count')).to_have_text('2 / 6')
        check('Lecture automatique puis pause sans changement d’étape')
        page.locator('.day-button').nth(3).click()
        page.locator('.step-button').last.click()
        expect(page.locator('#next-step')).to_be_disabled()
        page.locator('#play-button').click()
        expect(page.locator('#step-count')).to_have_text('1 / 4')
        page.locator('.day-button').nth(1).click()
        expect(page.locator('#play-button')).to_have_attribute('aria-pressed', 'false')
        check('Relance à la dernière étape et arrêt lors du changement de jour')
        page.locator('.day-button').nth(3).click();page.locator('.step-button').nth(2).click()
        page.locator('#play-button').click();page.wait_for_timeout(7400)
        expect(page.locator('#step-count')).to_have_text('4 / 4')
        expect(page.locator('#play-button')).to_have_attribute('aria-pressed', 'false')
        check('Fin de lecture : arrêt automatique sans boucle ni minuterie restante')
        page.locator('#view-carnet').click()
        expect(page.locator('#carnet-view')).to_be_visible()
        expect(page.locator('.timeline-card')).to_have_count(22)
        for index, event in enumerate(expected['events']):
            page.locator(f'.timeline-card[data-event="{index}"]').click()
            expect(page.locator('#dialog-title')).to_have_text(event[2])
            expect(page.locator('#dialog-copy')).to_have_text(event[4])
            expect(page.locator('#dialog-status')).to_have_text(event[6])
            page.keyboard.press('Escape')
        check('Les 22 fiches du carnet conservent les détails originaux')
        page.locator('.timeline-card[data-event="8"]').click()
        expect(page.locator('#dialog-meals')).to_contain_text('Vegan’s Prague')
        expect(page.locator('#dialog-meals')).to_contain_text('Dosa Dosa')
        page.keyboard.press('Escape')
        check('Suggestions repas concurrentes conservées : Vegan’s Prague et Dosa Dosa')
        page.locator('.timeline-card[data-event="16"]').click()
        expect(page.locator('#dialog-site')).to_have_attribute('href', expected['events'][16][7])
        page.locator('#show-on-map').click()
        expect(page.locator('#map-view')).to_be_visible()
        expect(page.locator('#selected-title')).to_have_text('Dîner sur la Vltava')
        check('Passage carnet → carte à la bonne étape et lien réservation conservé')
        page.goto(base + '#jour=4&etape=4&vue=map', wait_until='domcontentloaded')
        expect(page.locator('#selected-title')).to_have_text('Des souvenirs plein les yeux')
        check('Lien direct partageable vers un jour et une étape')
        page.goto(base + '#jour=999&etape=-2&vue=oops', wait_until='domcontentloaded')
        expect(page.locator('#step-count')).to_have_text('1 / 6')
        check('Paramètres de lien invalides sans plantage')
        for width in [375, 390, 768, 1280, 1440, 1920]:
            page.set_viewport_size({'width': width, 'height': 1000})
            wait_ui(page)
            check(f'Affichage {width}px sans débordement horizontal', page.evaluate('document.documentElement.scrollWidth <= innerWidth'))
        page.set_viewport_size({'width': 1280, 'height': 1000})
        page.emulate_media(reduced_motion='reduce')
        page.locator('.day-button').nth(1).click();page.locator('.step-button').nth(3).click()
        check('Mouvement réduit : aucune animation longue', page.evaluate('document.getAnimations().filter(a=>a.playState==="running"&&a.effect.getTiming().duration>10).length') == 0)
        page.emulate_media(reduced_motion='no-preference')
        if args.axe:
            page.add_script_tag(path=args.axe)
            for theme in ['light', 'dark']:
                page.evaluate('(theme)=>document.documentElement.dataset.theme=theme', theme)
                wait_ui(page)
                for view in ['map', 'carnet']:
                    page.locator('#view-' + view).click();wait_ui(page)
                    violations = page.evaluate("async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});return r.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>n.target)}))}")
                    check(f'Accessibilité axe WCAG A/AA : {theme}, {view}', not violations)
            page.set_viewport_size({'width': 375, 'height': 812});page.locator('#view-map').click();wait_ui(page)
            violations = page.evaluate("async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});return r.violations.map(v=>v.id)}")
            check('Accessibilité axe sur mobile sombre', not violations)
        page.goto(base, wait_until='domcontentloaded')
        page.keyboard.press('Tab')
        expect(page.locator('.skip')).to_be_focused()
        check('Lien d’évitement accessible au clavier')
        page.locator('#details-button').click();page.keyboard.press('Escape')
        expect(page.locator('#details-button')).to_be_focused()
        check('Fermeture Échap et restitution du focus')
        context = browser.new_context(viewport={'width': 390, 'height': 844}, is_mobile=True, has_touch=True)
        mobile = context.new_page();mobile.goto(base,wait_until='domcontentloaded')
        mobile.locator('.day-button').nth(1).tap();mobile.locator('.map-pin[data-step="3"]').tap()
        expect(mobile.locator('#mobile-step-title')).to_contain_text('Malá Strana & Kampa')
        mobile.locator('#mobile-details').tap();expect(mobile.locator('#event-dialog')).to_be_visible()
        mobile.locator('#close-dialog').tap();mobile.locator('#mobile-play').tap()
        expect(mobile.locator('#play-button')).to_have_attribute('aria-pressed','true')
        mobile.locator('#mobile-play').tap()
        check('Interactions tactiles mobile : jours, repères, fiche et lecture')
        touch = context.new_cdp_session(mobile)
        rect = mobile.locator('#map-viewport').bounding_box()
        tx = rect['x'] + rect['width'] / 2; ty = rect['y'] + 220
        touch.send('Input.dispatchTouchEvent', {'type':'touchStart','touchPoints':[{'x':tx-25,'y':ty},{'x':tx+25,'y':ty}]})
        touch.send('Input.dispatchTouchEvent', {'type':'touchMove','touchPoints':[{'x':tx-55,'y':ty},{'x':tx+55,'y':ty}]})
        touch.send('Input.dispatchTouchEvent', {'type':'touchEnd','touchPoints':[]})
        check('Pincement tactile à deux doigts : agrandissement', 'scale(1)' not in mobile.locator('#map-stage').evaluate('(el)=>el.style.transform'))
        mobile.locator('#zoom-reset').tap()
        photo_page = browser.new_page()
        photo_page.route('https://commons.wikimedia.org/w/api.php?*', lambda route: route.fulfill(json={'query':{'pages':{'1':{'imageinfo':[{'url':'https://prague-photo.test/fixture.webp','extmetadata':{'Artist':{'value':'Auteur de test'},'LicenseShortName':{'value':'CC BY-SA 4.0'}}}]}}}}))
        photo_page.route('https://prague-photo.test/fixture.webp', lambda route:route.fulfill(path=str(root/'assets/prague-map.webp'),content_type='image/webp'))
        photo_page.goto(base,wait_until='domcontentloaded');photo_page.locator('.day-button').nth(1).click();photo_page.locator('#details-button').click()
        expect(photo_page.locator('#photo-area img')).to_have_count(1)
        expect(photo_page.locator('#photo-credit')).to_contain_text('Auteur de test')
        expect(photo_page.locator('#photo-credit')).to_contain_text('CC BY-SA 4.0')
        check('Succès API photo contrôlé : image, auteur et licence affichés (réponse simulée de test)')
        page.set_viewport_size({'width':1280,'height':1000})
        page.evaluate('document.body.style.zoom="2"');wait_ui(page)
        check('Zoom navigateur 200 % : pas de débordement horizontal',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
        page.evaluate('document.body.style.zoom="1"')
        offline = browser.new_page()
        offline.route('**/assets/prague-map.webp*', lambda route: route.abort())
        offline.route('https://commons.wikimedia.org/**', lambda route: route.abort())
        offline.goto(base, wait_until='domcontentloaded')
        expect(offline.locator('#map-fallback')).to_be_visible()
        offline.locator('#view-carnet').click();expect(offline.locator('.timeline-card')).to_have_count(22)
        offline.locator('.timeline-card[data-event="6"]').click()
        expect(offline.locator('.photo-message')).to_contain_text('Photo indisponible')
        check('Illustration et photos indisponibles : carnet complet et retour explicite')
        # La page restaurants n’est pas réécrite : vérifier sa navigation et ses filtres.
        restaurants = browser.new_page()
        restaurants.route('https://commons.wikimedia.org/**', lambda route: route.abort())
        restaurants.goto(base + 'restaurants.html', wait_until='domcontentloaded')
        expect(restaurants.locator('.card')).to_have_count(4)
        filters = restaurants.locator('[data-filter]')
        for i in range(filters.count()):
            button = filters.nth(i); kind = button.get_attribute('data-filter');button.click()
            visible = restaurants.locator('.card:visible').count()
            expected_count = 4 if kind == 'all' else restaurants.locator(f'.card[data-type="{kind}"]').count()
            check('Page restaurants : filtre ' + kind, visible == expected_count)
        check('Aucune erreur JavaScript non gérée', not errors)
        browser.close()
    report = {'status': 'PASS', 'checks': len(checks), 'browser': 'Chromium', 'tests': checks, 'javascript_errors': errors, 'programme_sha256': hashlib.sha256((root/'tests/programme-original.json').read_bytes()).hexdigest()}
except Exception as error:
    report = {'status': 'FAIL', 'checks_passed': len(checks), 'error': str(error), 'tests': checks, 'javascript_errors': errors}
finally:
    Path(args.output).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    if server:
        server.shutdown()
print(json.dumps({'status': report['status'], 'checks': len(checks), 'error': report.get('error')}, ensure_ascii=False))
if report['status'] != 'PASS':
    raise SystemExit(1)
