# Livraison Prague — publication NON effectuée

Version locale testée : `431ca1c02bd91b38257f3043bd2c1d941cd26536`.
Base distante prise en compte : `758a15804d5e7b710fdb9a4f7397e1754d599b78`.

Le développement et les tests sont terminés ; le push a échoué parce qu’aucun
compte GitHub n’est authentifié dans cet environnement. Le site public a été
contrôlé et ne contient pas cette nouvelle application. Ne pas confondre cette
archive ou le commit local avec un déploiement en ligne.

## Contenu

- `prague/` : version complète du dossier, uniquement ce projet.
- `prague-final.patch` : patch du commit local, limité à `prague/`.
- `verification-publication.json` : contrôles de révision et erreur du push.
- `captures/` : captures navigateur desktop, mobile, sombre et détails.
- `prague/tests/results.json` : 67 contrôles PASS.

L’aperçu HTML autonome est fourni séparément. Le dossier `prague/` est la version
à utiliser pour le dépôt et GitHub Pages.

## Publier sans toucher aux autres projets

Depuis une copie locale authentifiée du dépôt :

```sh
git switch main
git pull --ff-only
git status --short
# Si des modifications locales existent, les mettre à l’abri avant la suite.
# Ne pas utiliser reset --hard ni push --force.
git apply --check /chemin/vers/prague-final.patch
git apply /chemin/vers/prague-final.patch
git add -- prague
git diff --cached --stat
git diff --cached --check
git commit -m "Finalize Prague interactive illustrated map and preserve trip programme"
git push origin main
```

Si `git apply --check` signale un conflit, ne pas forcer : comparer les nouvelles
modifications distantes, en particulier `assets/itinerary.js`, puis réconcilier.
Le patch a été construit sur la base indiquée ci-dessus ; un travail concurrent
ultérieur doit être relu plutôt qu’écrasé.

Après le push : vérifier la réussite de l’action de déploiement GitHub Pages,
puis ouvrir `https://woofer121.github.io/sites/prague/`, forcer l’actualisation et
contrôler les commandes Carte/Carnet, les quatre jours et la lecture du parcours.
Le HTML publié doit référencer `./assets/app.js`.

Le test est local dans Chromium. Safari/Firefox et le futur déploiement réel
n’ont pas été validés. Les photos et polices dépendent d’Internet ; l’illustration
et le programme sont locaux. Le succès de chargement photo utilise aussi une
réponse contrôlée dans les tests ; il n’atteste pas une disponibilité future de
Wikimedia. Les tarifs et réservations sont ceux du carnet, pas des achats faits ici.
